/* =========================================================================
   PARKING MANAGEMENT SYSTEM  --  single-file, object-oriented C++ (main.cpp)
   -------------------------------------------------------------------------
   - Binary file persistence via <fstream>  : active_parking.dat,
                                                parking_history.dat
   - ParkingLot object holds the slots[50] array and mirrors
     active_parking.dat on boot
   - Role-based access: Staff (1111) / Admin (9999), 3 login attempts
   - Cross-platform screen clearing between every screen transition

   CLASSES
     ParkingSlot     - one parking slot (data + behavior)
     HistoryRecord   - one completed transaction
     Screen          - screen / pause helpers
     Input           - sanitized console input helpers
     TimeUtil        - time formatting
     Billing         - fee calculation
     AuthManager     - login / logout / current role
     ParkingLot      - the lot: file sync + check-in/out/search/status/revenue
     ParkingSystem   - top-level controller: menu loop, owns the objects
   ========================================================================= */

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <cctype>
#include <iomanip>
#include <vector>

using namespace std;

// =========================================================================
//  CONSTANTS
// =========================================================================

const int    TOTAL_SLOTS   = 50;     // slots numbered 1..50
const int    GRID_COLS     = 10;     // visual grid: 10 columns
const int    GRID_ROWS     = 5;      //              x 5 rows  (=50)

const int    STAFF_PASSKEY = 1111;
const int    ADMIN_PASSKEY = 9999;
const int    MAX_LOGIN_ATTEMPTS = 3;

const double RATE_PER_HOUR = 2.00;   // $2.00 / hour
const double MIN_FEE       = 2.00;   // minimum charge per checkout

const char   ACTIVE_FILE[]  = "active_parking.dat";
const char   HISTORY_FILE[] = "parking_history.dat";

const int PLATE_LEN = 15;
const int VTYPE_LEN = 12;

const int ROLE_NONE  = 0;
const int ROLE_STAFF = 1;
const int ROLE_ADMIN = 2;


// =========================================================================
//  CLASS: Screen   (system / screen helpers)
// =========================================================================

class Screen {
public:
    static void clear() {
#ifdef _WIN32
        system("cls");
#else
        system("clear");
#endif
    }

    // If the input stream has been closed (EOF, e.g. Ctrl+D or a closed pipe),
    // the read-until-valid loops would otherwise spin forever printing
    // error messages. Detect that condition and shut down cleanly instead.
    static void checkEOFOrExit() {
        if (cin.eof()) {
            cout << "\n[!] Input stream closed. Exiting system.\n";
            exit(0);
        }
    }

    static void waitForEnter() {
        cout << "\nPress Enter to continue...";
        string dummy;
        getline(cin, dummy);
        checkEOFOrExit();
    }

    static void printSeparator(char ch, int len) {
        cout << string(len, ch) << "\n";
    }
};


// =========================================================================
//  CLASS: TimeUtil
// =========================================================================

class TimeUtil {
public:
    static string formatTime(time_t t) {
        if (t == 0) return "N/A";
        struct tm *tm_info = localtime(&t);
        char buffer[26];
        strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", tm_info);
        return string(buffer);
    }
};


// =========================================================================
//  CLASS: Billing
// =========================================================================

class Billing {
public:
    static double calculateFee(time_t inTime, time_t outTime, double &hoursOut) {
        double seconds = difftime(outTime, inTime);
        if (seconds < 0) seconds = 0;
        double hours = seconds / 3600.0;
        hoursOut = hours;

        int billableHours = (int)ceil(hours);
        if (billableHours < 1) billableHours = 1;      // at least 1 billable hour

        double fee = billableHours * RATE_PER_HOUR;
        if (fee < MIN_FEE) fee = MIN_FEE;              // enforce $2.00 minimum
        return fee;
    }
};


// =========================================================================
//  CLASS: Input   (sanitized input helpers)
// =========================================================================

class Input {
public:
    static string trim(const string &s) {
        size_t start = s.find_first_not_of(" \t\r\n");
        if (start == string::npos) return "";
        size_t end = s.find_last_not_of(" \t\r\n");
        return s.substr(start, end - start + 1);
    }

    static string toUpperStr(const string &s) {
        string r = s;
        for (char &c : r) c = (char)toupper((unsigned char)c);
        return r;
    }

    static bool isValidPlateString(const string &s) {
        if (s.empty() || (int)s.size() >= PLATE_LEN) return false;
        for (char c : s) {
            if (!isalnum((unsigned char)c) && c != '-' && c != ' ') return false;
        }
        return true;
    }

    static bool isValidVehicleTypeString(const string &s) {
        if (s.empty() || (int)s.size() >= VTYPE_LEN) return false;
        for (char c : s) {
            if (!isalpha((unsigned char)c) && c != ' ') return false;
        }
        return true;
    }

    // Loops until a syntactically valid plate number is entered.
    static string readPlate(const string &prompt) {
        string line;
        while (true) {
            cout << prompt;
            getline(cin, line);
            Screen::checkEOFOrExit();
            line = trim(line);
            line = toUpperStr(line);
            if (isValidPlateString(line)) return line;
            cout << "  [!] Invalid plate. Use letters/digits/dashes only (max "
                 << (PLATE_LEN - 1) << " chars). Try again.\n";
        }
    }

    // Loops until a syntactically valid vehicle type is entered.
    static string readVehicleType(const string &prompt) {
        string line;
        while (true) {
            cout << prompt;
            getline(cin, line);
            Screen::checkEOFOrExit();
            line = trim(line);
            if (isValidVehicleTypeString(line)) {
                for (char &c : line) c = (char)tolower((unsigned char)c);
                line[0] = (char)toupper((unsigned char)line[0]);
                return line;
            }
            cout << "  [!] Invalid type. Letters only (e.g. Car, Bike, Truck), max "
                 << (VTYPE_LEN - 1) << " chars. Try again.\n";
        }
    }

    // Reads one line and returns true only if it is a clean integer.
    static bool readIntStrict(const string &prompt, int &out) {
        string line;
        if (!prompt.empty()) cout << prompt;
        getline(cin, line);
        Screen::checkEOFOrExit();
        line = trim(line);
        if (line.empty()) return false;

        size_t idx = 0;
        if (line[0] == '-' || line[0] == '+') idx = 1;
        if (idx >= line.size()) return false;
        for (size_t i = idx; i < line.size(); ++i) {
            if (!isdigit((unsigned char)line[i])) return false;
        }
        try {
            out = stoi(line);
        } catch (...) {
            return false;
        }
        return true;
    }

    // Loops until 'Y' or 'N' (case-insensitive) is entered.
    static char readYesNo(const string &prompt) {
        string line;
        while (true) {
            cout << prompt;
            getline(cin, line);
            Screen::checkEOFOrExit();
            line = trim(line);
            if (!line.empty()) {
                char c = (char)toupper((unsigned char)line[0]);
                if (c == 'Y' || c == 'N') return c;
            }
            cout << "  [!] Please enter Y or N.\n";
        }
    }
};


// =========================================================================
//  CLASS: ParkingSlot
//  (no virtual functions, same member order as before -> the binary layout
//   of active_parking.dat is unchanged and existing files still load)
// =========================================================================

class ParkingSlot {
private:
    int    slotNumber;               // 1..50
    bool   occupied;                 // false = Free (0), true = Occupied (1)
    char   plateNumber[PLATE_LEN];
    char   vehicleType[VTYPE_LEN];
    time_t entryTime;

public:
    ParkingSlot() {
        init(0);
    }

    // Makes this slot free and gives it its number.
    void init(int number) {
        slotNumber = number;
        occupied   = false;
        memset(plateNumber, 0, PLATE_LEN);
        memset(vehicleType, 0, VTYPE_LEN);
        entryTime  = 0;
    }

    // Parks a vehicle in this slot (entry time = now).
    void park(const string &plate, const string &vtype) {
        occupied = true;
        strncpy(plateNumber, plate.c_str(), PLATE_LEN - 1);
        plateNumber[PLATE_LEN - 1] = '\0';
        strncpy(vehicleType, vtype.c_str(), VTYPE_LEN - 1);
        vehicleType[VTYPE_LEN - 1] = '\0';
        entryTime = time(nullptr);
    }

    // Frees this slot (slot number is kept).
    void release() {
        occupied = false;
        memset(plateNumber, 0, PLATE_LEN);
        memset(vehicleType, 0, VTYPE_LEN);
        entryTime = 0;
    }

    // Getters
    int         getSlotNumber() const { return slotNumber; }
    bool        isOccupied()    const { return occupied; }
    const char *getPlate()      const { return plateNumber; }
    const char *getType()       const { return vehicleType; }
    time_t      getEntryTime()  const { return entryTime; }

    // Raw binary I/O
    void writeTo(ofstream &out) const {
        out.write(reinterpret_cast<const char *>(this), sizeof(ParkingSlot));
    }
    void readFrom(ifstream &in) {
        in.read(reinterpret_cast<char *>(this), sizeof(ParkingSlot));
    }
};


// =========================================================================
//  CLASS: HistoryRecord   (one completed transaction)
// =========================================================================

class HistoryRecord {
private:
    int    slotNumber;
    char   plateNumber[PLATE_LEN];
    char   vehicleType[VTYPE_LEN];
    time_t entryTime;
    time_t exitTime;
    double hoursParked;
    double fee;

public:
    HistoryRecord() {
        slotNumber = 0;
        memset(plateNumber, 0, PLATE_LEN);
        memset(vehicleType, 0, VTYPE_LEN);
        entryTime = 0;
        exitTime = 0;
        hoursParked = 0.0;
        fee = 0.0;
    }

    // Builds a record from a slot that is being checked out.
    HistoryRecord(const ParkingSlot &slot, time_t outTime, double hours, double feeCharged) {
        slotNumber = slot.getSlotNumber();
        strncpy(plateNumber, slot.getPlate(), PLATE_LEN - 1);
        plateNumber[PLATE_LEN - 1] = '\0';
        strncpy(vehicleType, slot.getType(), VTYPE_LEN - 1);
        vehicleType[VTYPE_LEN - 1] = '\0';
        entryTime   = slot.getEntryTime();
        exitTime    = outTime;
        hoursParked = hours;
        fee         = feeCharged;
    }

    // Getters
    int         getSlotNumber() const { return slotNumber; }
    const char *getPlate()      const { return plateNumber; }
    const char *getType()       const { return vehicleType; }
    time_t      getEntryTime()  const { return entryTime; }
    time_t      getExitTime()   const { return exitTime; }
    double      getHours()      const { return hoursParked; }
    double      getFee()        const { return fee; }

    // Raw binary I/O
    void writeTo(ofstream &out) const {
        out.write(reinterpret_cast<const char *>(this), sizeof(HistoryRecord));
    }
    bool readFrom(ifstream &in) {
        in.read(reinterpret_cast<char *>(this), sizeof(HistoryRecord));
        return static_cast<bool>(in);
    }
};


// =========================================================================
//  CLASS: AuthManager   (authentication + current role)
// =========================================================================

class AuthManager {
private:
    int currentRole;

public:
    AuthManager() : currentRole(ROLE_NONE) {}

    int  getRole()  const { return currentRole; }
    bool isAdmin()  const { return currentRole == ROLE_ADMIN; }
    bool isStaff()  const { return currentRole == ROLE_STAFF; }

    bool login() {
        currentRole = ROLE_NONE;
        Screen::clear();

        Screen::printSeparator('=', 60);
        cout << "          PARKING MANAGEMENT SYSTEM - LOGIN GATE\n";
        Screen::printSeparator('=', 60);

        for (int attempt = 1; attempt <= MAX_LOGIN_ATTEMPTS; ++attempt) {
            int passkey;
            string prompt = "Enter Passkey (" +
                             to_string(MAX_LOGIN_ATTEMPTS - attempt + 1) +
                             " attempt(s) left): ";

            if (!Input::readIntStrict(prompt, passkey)) {
                cout << "  [!] Invalid input. Passkey must be numeric.\n";
                continue;
            }

            if (passkey == STAFF_PASSKEY) {
                currentRole = ROLE_STAFF;
                cout << "\nLogin successful. Welcome, STAFF.\n";
                return true;
            } else if (passkey == ADMIN_PASSKEY) {
                currentRole = ROLE_ADMIN;
                cout << "\nLogin successful. Welcome, ADMIN.\n";
                return true;
            } else {
                cout << "  [!] Incorrect passkey.\n";
            }
        }

        cout << "\nToo many failed attempts. Exiting system.\n";
        return false;
    }

    void logout() {
        cout << "Logging out... Returning to login gate.\n";
        currentRole = ROLE_NONE;
        Screen::waitForEnter();
    }
};


// =========================================================================
//  CLASS: ParkingLot
//  Owns the slots[] array, keeps it in sync with active_parking.dat and
//  implements every parking feature.
// =========================================================================

class ParkingLot {
private:
    ParkingSlot slots[TOTAL_SLOTS];   // RAM array synced with ACTIVE_FILE

    // -- file & RAM sync --------------------------------------------------

    // Fills slots[] with 50 empty/free slots and writes it to disk.
    void initializeFreshLot() {
        for (int i = 0; i < TOTAL_SLOTS; ++i) {
            slots[i].init(i + 1);      // slots are 1..50, all free
        }
        saveActiveFile();
    }

    // Appends one completed transaction to the history ledger (never overwritten).
    void appendHistory(const HistoryRecord &rec) {
        ofstream histFile(HISTORY_FILE, ios::binary | ios::app);
        if (!histFile) {
            cout << "  [ERROR] Unable to open " << HISTORY_FILE << "\n";
            return;
        }
        rec.writeTo(histFile);
        histFile.close();
    }

    // -- lookup -----------------------------------------------------------

    int findFreeSlot() const {
        for (int i = 0; i < TOTAL_SLOTS; ++i) {
            if (!slots[i].isOccupied()) return i;
        }
        return -1;
    }

    int findSlotByPlate(const string &plate) const {
        for (int i = 0; i < TOTAL_SLOTS; ++i) {
            if (slots[i].isOccupied() && plate == slots[i].getPlate()) return i;
        }
        return -1;
    }

public:
    // Boot-time sync: reads active_parking.dat into the RAM array.
    // If the file is missing or incomplete/corrupt, a fresh 50-slot lot is created.
    void loadActiveFile() {
        ifstream inFile(ACTIVE_FILE, ios::binary);
        if (!inFile) {
            initializeFreshLot();
            return;
        }

        inFile.seekg(0, ios::end);
        long size = (long)inFile.tellg();
        inFile.seekg(0, ios::beg);

        if (size < (long)(sizeof(ParkingSlot) * TOTAL_SLOTS)) {
            inFile.close();
            initializeFreshLot();
            return;
        }

        for (int i = 0; i < TOTAL_SLOTS; ++i) {
            slots[i].readFrom(inFile);
        }
        inFile.close();
    }

    // Persists the current RAM array back to active_parking.dat.
    // The file always holds a complete, current image of all 50 slots, so it is
    // rewritten (not literally appended) every time a slot's state changes --
    // this is what keeps active_parking.dat permanently "in sync" with RAM.
    void saveActiveFile() {
        ofstream outFile(ACTIVE_FILE, ios::binary | ios::trunc);
        if (!outFile) {
            cout << "  [ERROR] Unable to write to " << ACTIVE_FILE << "\n";
            return;
        }
        for (int i = 0; i < TOTAL_SLOTS; ++i) {
            slots[i].writeTo(outFile);
        }
        outFile.close();
    }

    // ---------------------------------------------------------------------
    //  OPTION 1: CHECK-IN
    // ---------------------------------------------------------------------
    void checkIn() {
        Screen::printSeparator('=', 60);
        cout << " CHECK-IN VEHICLE\n";
        Screen::printSeparator('=', 60);

        char again = 'Y';
        while (again == 'Y') {
            int idx = findFreeSlot();
            if (idx == -1) {
                cout << "  [!] Parking lot is FULL. No available slots.\n";
            } else {
                string plate = Input::readPlate("  Enter Plate Number: ");

                if (findSlotByPlate(plate) != -1) {
                    cout << "  [!] This vehicle is already checked in. Skipping.\n";
                } else {
                    string vtype = Input::readVehicleType("  Enter Vehicle Type (Car/Bike/Truck/etc): ");

                    slots[idx].park(plate, vtype);

                    saveActiveFile();   // sync RAM -> active_parking.dat

                    cout << "\n  --------------- PARKING TICKET ---------------\n";
                    cout << "    Slot Number   : " << slots[idx].getSlotNumber() << "\n";
                    cout << "    Plate Number  : " << plate << "\n";
                    cout << "    Vehicle Type  : " << vtype << "\n";
                    cout << "    Entry Time    : " << TimeUtil::formatTime(slots[idx].getEntryTime()) << "\n";
                    cout << "  ------------------------------------------------\n";
                }
            }
            again = Input::readYesNo("\n  Check in another vehicle? (Y/N): ");
        }
    }

    // ---------------------------------------------------------------------
    //  OPTION 2: CHECK-OUT
    // ---------------------------------------------------------------------
    void checkOut() {
        Screen::printSeparator('=', 60);
        cout << " CHECK-OUT VEHICLE\n";
        Screen::printSeparator('=', 60);

        char again = 'Y';
        while (again == 'Y') {
            string plate = Input::readPlate("  Enter Plate Number to check out: ");
            int idx = findSlotByPlate(plate);

            if (idx == -1) {
                cout << "  [!] No active parking record found for plate \"" << plate << "\".\n";
            } else {
                time_t outTime = time(nullptr);
                double hours;
                double fee = Billing::calculateFee(slots[idx].getEntryTime(), outTime, hours);

                HistoryRecord rec(slots[idx], outTime, hours, fee);

                appendHistory(rec);   // append transaction to parking_history.dat

                cout << "\n  ------------------ INVOICE ---------------------\n";
                cout << "    Slot Number     : " << rec.getSlotNumber() << "\n";
                cout << "    Plate Number    : " << rec.getPlate() << "\n";
                cout << "    Vehicle Type    : " << rec.getType() << "\n";
                cout << "    Entry Time      : " << TimeUtil::formatTime(rec.getEntryTime()) << "\n";
                cout << "    Exit Time       : " << TimeUtil::formatTime(rec.getExitTime()) << "\n";
                cout << fixed << setprecision(2);
                cout << "    Duration        : " << hours << " hr(s)\n";
                cout << "    Rate            : $" << RATE_PER_HOUR << " / hr (min $" << MIN_FEE << ")\n";
                cout << "    TOTAL FEE       : $" << fee << "\n";
                cout << "  ------------------------------------------------\n";

                // Mark slot free in RAM, then sync to active_parking.dat
                slots[idx].release();
                saveActiveFile();
            }
            again = Input::readYesNo("\n  Check out another vehicle? (Y/N): ");
        }
    }

    // ---------------------------------------------------------------------
    //  OPTION 3: SEARCH VEHICLE (READ-ONLY)
    // ---------------------------------------------------------------------
    void searchVehicle() {
        Screen::printSeparator('=', 60);
        cout << " SEARCH VEHICLE\n";
        Screen::printSeparator('=', 60);

        string plate = Input::readPlate("  Enter Plate Number: ");
        int idx = findSlotByPlate(plate);

        if (idx == -1) {
            cout << "  [!] No active vehicle found with plate \"" << plate << "\".\n";
            return;
        }

        time_t now = time(nullptr);
        double hours;
        double fee = Billing::calculateFee(slots[idx].getEntryTime(), now, hours);

        cout << "\n  --- Vehicle Found ---\n";
        cout << "    Slot Number     : " << slots[idx].getSlotNumber() << "\n";
        cout << "    Plate Number    : " << slots[idx].getPlate() << "\n";
        cout << "    Vehicle Type    : " << slots[idx].getType() << "\n";
        cout << "    Entry Time      : " << TimeUtil::formatTime(slots[idx].getEntryTime()) << "\n";
        cout << fixed << setprecision(2);
        cout << "    Elapsed Time    : " << hours << " hr(s)\n";
        cout << "    Accrued Fee     : $" << fee << " (live estimate, not yet charged)\n";
    }

    // ---------------------------------------------------------------------
    //  OPTION 4: VIEW LOT STATUS (GRID MAP + DETAIL TABLE)
    // ---------------------------------------------------------------------
    void viewStatus() const {
        Screen::printSeparator('=', 60);
        cout << " PARKING LOT STATUS\n";
        Screen::printSeparator('=', 60);

        int occupiedCount = 0;
        for (int i = 0; i < TOTAL_SLOTS; ++i) {
            if (slots[i].isOccupied()) ++occupiedCount;
        }

        cout << "  Capacity  : " << TOTAL_SLOTS << "\n";
        cout << "  Occupied  : " << occupiedCount << "\n";
        cout << "  Free      : " << (TOTAL_SLOTS - occupiedCount) << "\n\n";

        cout << "  VISUAL GRID MAP  (" << GRID_COLS << " x " << GRID_ROWS
             << ")   [O] Occupied   [X] Free\n";
        Screen::printSeparator('-', 60);

        int slotIdx = 0;
        for (int r = 0; r < GRID_ROWS; ++r) {
            for (int c = 0; c < GRID_COLS; ++c) {
                cout << (slots[slotIdx].isOccupied() ? "[O]" : "[X]");
                ++slotIdx;
            }
            cout << "\n";
        }

        Screen::printSeparator('-', 60);
        cout << "  DETAILED ACTIVE VEHICLE TABLE\n";
        Screen::printSeparator('-', 60);

        if (occupiedCount == 0) {
            cout << "  (No vehicles currently parked.)\n";
            return;
        }

        cout << left << setw(6) << "Slot" << setw(16) << "Plate" << setw(12)
             << "Type" << setw(20) << "Entry Time" << "\n";
        Screen::printSeparator('-', 60);

        for (int i = 0; i < TOTAL_SLOTS; ++i) {
            if (slots[i].isOccupied()) {
                cout << left << setw(6) << slots[i].getSlotNumber()
                     << setw(16) << slots[i].getPlate()
                     << setw(12) << slots[i].getType()
                     << setw(20) << TimeUtil::formatTime(slots[i].getEntryTime()) << "\n";
            }
        }
    }

    // ---------------------------------------------------------------------
    //  OPTION 5 (ADMIN ONLY): REVENUE & FINANCIAL HISTORY
    // ---------------------------------------------------------------------
    void viewRevenue(const AuthManager &auth) const {
        if (!auth.isAdmin()) {
            cout << "  [!] Access Denied: Admins only.\n";
            return;
        }

        Screen::printSeparator('=', 60);
        cout << " REVENUE & FINANCIAL HISTORY (Administrator Only)\n";
        Screen::printSeparator('=', 60);

        ifstream histFile(HISTORY_FILE, ios::binary);
        if (!histFile) {
            cout << "  (No transaction history found yet.)\n";
            return;
        }

        vector<HistoryRecord> records;
        HistoryRecord rec;
        double totalRevenue = 0.0;
        double totalHours   = 0.0;

        while (rec.readFrom(histFile)) {
            records.push_back(rec);
            totalRevenue += rec.getFee();
            totalHours   += rec.getHours();
        }
        histFile.close();

        cout << fixed << setprecision(2);
        cout << "  Total Transactions : " << records.size() << "\n";
        cout << "  Total Revenue      : $" << totalRevenue << "\n";
        if (!records.empty()) {
            cout << "  Average Fee/Txn    : $" << (totalRevenue / records.size()) << "\n";
            cout << "  Average Hours/Txn  : " << (totalHours / records.size()) << " hr(s)\n";
        }

        Screen::printSeparator('-', 60);
        cout << "  ITEMIZED TRANSACTION LEDGER\n";
        Screen::printSeparator('-', 60);

        if (records.empty()) {
            cout << "  (No transactions recorded.)\n";
            return;
        }

        cout << left << setw(6) << "Slot" << setw(14) << "Plate" << setw(10)
             << "Type" << setw(20) << "Entry" << setw(20) << "Exit"
             << setw(8) << "Hours" << "Fee" << "\n";
        Screen::printSeparator('-', 60);

        for (size_t i = 0; i < records.size(); ++i) {
            const HistoryRecord &h = records[i];
            cout << left << setw(6) << h.getSlotNumber() << setw(14) << h.getPlate()
                 << setw(10) << h.getType() << setw(20) << TimeUtil::formatTime(h.getEntryTime())
                 << setw(20) << TimeUtil::formatTime(h.getExitTime())
                 << setw(8) << h.getHours() << "$" << h.getFee() << "\n";
        }
    }
};


// =========================================================================
//  CLASS: ParkingSystem   (top-level controller: menu + session loop)
// =========================================================================

class ParkingSystem {
private:
    ParkingLot  lot;
    AuthManager auth;

    void showMainMenu() const {
        Screen::printSeparator('=', 60);
        cout << "           PARKING MANAGEMENT SYSTEM - MAIN MENU\n";
        cout << "           Logged in as: "
             << (auth.isAdmin() ? "ADMIN / MANAGER" : "STAFF / DESK CLERK") << "\n";
        Screen::printSeparator('=', 60);
        cout << "[1] Check-In Vehicle\n";
        cout << "[2] Check-Out Vehicle\n";
        cout << "[3] Search Vehicle\n";
        cout << "[4] View Lot Status\n";

        if (auth.isAdmin()) {
            cout << "[5] View Revenue & Financial History\n";
            cout << "[6] Exit System\n";
        } else {
            cout << "[5] Log Out\n";
            // Option 6 is hidden entirely for Staff -- they cannot close the program.
        }
        Screen::printSeparator('-', 60);
    }

    void runMenu() {
        bool active = true;
        while (active) {
            Screen::clear();
            showMainMenu();

            int choice;
            if (!Input::readIntStrict("Enter choice: ", choice)) {
                cout << "  [!] Invalid input. Please enter a number.\n";
                Screen::waitForEnter();
                continue;
            }

            switch (choice) {
                case 1:
                    Screen::clear();
                    lot.checkIn();
                    Screen::waitForEnter();
                    break;

                case 2:
                    Screen::clear();
                    lot.checkOut();
                    Screen::waitForEnter();
                    break;

                case 3:
                    Screen::clear();
                    lot.searchVehicle();
                    Screen::waitForEnter();
                    break;

                case 4:
                    Screen::clear();
                    lot.viewStatus();
                    Screen::waitForEnter();
                    break;

                case 5:
                    Screen::clear();
                    if (auth.isStaff()) {
                        auth.logout();
                        active = false;      // return to login gate
                    } else {
                        lot.viewRevenue(auth);
                        Screen::waitForEnter();
                    }
                    break;

                case 6:
                    if (auth.isAdmin()) {
                        Screen::clear();
                        cout << "Shutting down system. Goodbye, Administrator.\n";
                        exit(0);
                    } else {
                        cout << "  [!] Invalid option.\n";
                        Screen::waitForEnter();
                    }
                    break;

                default:
                    cout << "  [!] Invalid menu option.\n";
                    Screen::waitForEnter();
            }
        }
    }

public:
    void run() {
        lot.loadActiveFile();   // boot-time sync: file -> RAM (creates file if absent)

        bool systemActive = true;
        while (systemActive) {
            if (auth.login()) {
                runMenu();          // returns here only when Staff logs out
            } else {
                systemActive = false; // out of login attempts
            }
        }

        Screen::clear();
        cout << "Session ended. Goodbye!\n";
    }
};


// =========================================================================
//  MAIN
// =========================================================================

int main() {
    ParkingSystem app;
    app.run();
    return 0;
}