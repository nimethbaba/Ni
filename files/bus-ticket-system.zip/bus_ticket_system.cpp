#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cctype>
#include <limits>
#include <random>
#include <ctime>
#include <iomanip>
#include <cstdlib>
#include <conio.h>
using namespace std;

// ---------- STRUCTURES ----------
struct Bus {
    int id;
    string number;
    string name;
    string source;
    string destination;
    string date;
    string time;
    int price;
    int seats;
};

struct Booking {
    int ticketNo;
    string passengerName;
    string contact;
    int busId;
    int seatNo;
    string paymentStatus;
    string busNumber;
    string date;
    string time;
    int price;
};

// ---------- FUNCTION DECLARATION ----------
string readPasswordMasked();
void adminMenu();

int getNextBusId();
int getRandomBusId();
bool busIdExists(int id);
bool busNumberExists(const string& number);
bool busNumberExistsExcept(const string& number, int exceptId);
bool parseBusLine(const string& line, Bus& b);
string trim(const string& s);
bool isLeapYear(int year);
bool parseDate(const string& dateStr, int& day, int& month, int& year);
bool isValidDate(const string& dateStr);

int readPositiveInt(const string& prompt);
void addBus();
void viewBus();
void updateBus();
void deleteBus();
void saveDeletedBus(const Bus& b);
void saveCancelledBooking(const Booking& bk);

int getRandomTicketNo();
bool ticketNoExists(int ticketNo);

void bookTicket();
void viewBookings();
void updateBooking();
void cancelBooking();
bool parseBookingLine(const string& line, Booking& bk);

int readPositiveInt(const string& prompt) {
    int value;
    while (true) {
        cout << prompt;
        cin >> value;

        if (cin.fail() || value <= 0) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Please enter a valid positive number.\n";
        } else {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return value;
        }
    }
}

string readPasswordMasked() {
    string password;
    char ch;

    while (true) {
        ch = _getch();

        if (ch == 13) {
            cout << "\n";
            break;
        }
        else if (ch == 8) {
            if (!password.empty()) {
                password.pop_back();
                cout << "\b \b";
            }
        }
        else {
            password.push_back(ch);
            cout << '*';
        }
    }

    return password;
}

// ---------- SCREEN HELPERS ----------
void clearScreen() {
    system("cls");
}

void pauseForEnter() {
    // Reset any error state and discard leftover buffered input
    cin.clear();
    streamsize pending = cin.rdbuf()->in_avail();
    if (pending > 0) {
        cin.ignore(pending);
    }

    cout << "\nPress Enter to continue...";
    int ch;
    do {
        ch = _getch();
    } while (ch != 13);
    cout << "\n";
}

// ---------- MAIN FUNCTION ----------
int main() {
    int choice;

    while (true) {
        clearScreen();
        cout << "\n===== MAIN MENU =====\n";
        cout << "1. Admin\n2. Exit\n";
        cout << "Enter choice: ";

        while (true) {
            if (!(cin >> choice)) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Invalid Choice!\n";
                cout << "Enter choice: ";
                continue;
            }

            if (choice == 1) {
                string user, pass;
                clearScreen();
                cout << "Enter Username: ";
                user = readPasswordMasked();
                cout << "Enter Password: ";
                pass = readPasswordMasked();

                if (user == "admin" && pass == "1234") {
                    cout << "Login Successful!\n";
                    adminMenu();
                } else {
                    cout << "Invalid Username or Password!\n";
                    pauseForEnter();
                }
                break;
            }
            else if (choice == 2) {
                cout << "Program Terminated!\n";
                return 0;
            }
            else {
                cout << "Invalid Choice!\n";
                cout << "Enter choice: ";
            }
        }
    }

    return 0;
}
// ---------- ADMIN MENU ----------
void adminMenu() {
    int choice;

    while (true) {
        clearScreen();
        cout << "\n===== ADMIN MENU =====\n";
        cout << "1. Add Bus\n2. View Buses\n3. Update Bus\n4. Delete Bus\n";
        cout << "5. Book Ticket\n6. View Bookings\n7. Update Booking\n8. Cancel Booking\n9. Logout\n";
        cout << "Enter choice: ";

        while (true) {
            if (!(cin >> choice)) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Invalid choice!\n";
                cout << "Enter choice: ";
                continue;
            }

            clearScreen();

            switch (choice) {
                case 1: addBus(); break;
                case 2: viewBus(); break;
                case 3: updateBus(); break;
                case 4: deleteBus(); break;
                case 5: bookTicket(); break;
                case 6: viewBookings(); break;
                case 7: updateBooking(); break;
                case 8: cancelBooking(); break;
                case 9: return;
                default: cout << "Invalid choice!\n";
            }
            pauseForEnter();
            break;
        }
    }
}

// ---------- BUS FUNCTIONS ----------
int getNextBusId() {
    ifstream file("bus.txt");
    int nextId = 1;
    string line;

    while (getline(file, line)) {
        if (!line.empty()) {
            Bus b;
            if (parseBusLine(line, b) && b.id >= nextId) {
                nextId = b.id + 1;
            }
        }
    }

    file.close();
    return nextId;
}

int getRandomBusId() {
    static random_device rd;
    static mt19937 gen(rd());
    static uniform_int_distribution<int> dist(1000, 9999);

    int id;
    do {
        id = dist(gen);
    } while (busIdExists(id));

    return id;
}

bool busIdExists(int id) {
    ifstream file("bus.txt");
    if (!file) {
        return false;
    }

    string line;
    while (getline(file, line)) {
        if (line.empty()) {
            continue;
        }

        Bus b;
        if (parseBusLine(line, b) && b.id == id) {
            return true;
        }
    }

    return false;
}

bool busNumberExists(const string& number) {
    ifstream file("bus.txt");
    if (!file) {
        return false;
    }

    string line;
    string normalized = trim(number);
    transform(normalized.begin(), normalized.end(), normalized.begin(), ::tolower);

    while (getline(file, line)) {
        if (line.empty()) {
            continue;
        }

        Bus b;
        if (parseBusLine(line, b)) {
            string existing = trim(b.number);
            transform(existing.begin(), existing.end(), existing.begin(), ::tolower);
            if (existing == normalized) {
                return true;
            }
        }
    }

    return false;
}

bool busNumberExistsExcept(const string& number, int exceptId) {
    ifstream file("bus.txt");
    if (!file) {
        return false;
    }

    string line;
    string normalized = trim(number);
    transform(normalized.begin(), normalized.end(), normalized.begin(), ::tolower);

    while (getline(file, line)) {
        if (line.empty()) {
            continue;
        }

        Bus b;
        if (parseBusLine(line, b) && b.id != exceptId) {
            string existing = trim(b.number);
            transform(existing.begin(), existing.end(), existing.begin(), ::tolower);
            if (existing == normalized) {
                return true;
            }
        }
    }

    return false;
}

bool parseBusLine(const string& line, Bus& b) {
    stringstream ss(line);
    string part;

    b = {};

    if (!getline(ss, part, '|')) return false;
    if (part.rfind("ID: ", 0) != 0) return false;
    b.id = stoi(part.substr(4));

    if (!getline(ss, part, '|')) return false;
    if (part.rfind("Name: ", 0) != 0) return false;
    b.name = part.substr(6);

    if (!getline(ss, part, '|')) return false;
    if (part.rfind("Number: ", 0) != 0) return false;
    b.number = part.substr(8);

    if (!getline(ss, part, '|')) return false;
    if (part.rfind("Source: ", 0) != 0) return false;
    b.source = part.substr(8);

    if (!getline(ss, part, '|')) return false;
    if (part.rfind("Destination: ", 0) != 0) return false;
    b.destination = part.substr(13);

    if (!getline(ss, part, '|')) return false;
    if (part.rfind("Date: ", 0) != 0) return false;
    b.date = part.substr(6);

    if (!getline(ss, part, '|')) return false;
    if (part.rfind("Time: ", 0) != 0) return false;
    b.time = part.substr(6);

    if (getline(ss, part, '|')) {
        if (part.rfind("Price: ", 0) != 0) return false;
        b.price = stoi(part.substr(7));
    }

    if (getline(ss, part)) {
        if (part.rfind("Seats: ", 0) != 0) return false;
        b.seats = stoi(part.substr(7));
    }

    return true;
}

string trim(const string& s) {
    auto start = s.find_first_not_of(" \t\n\r");
    if (start == string::npos) return "";
    auto end = s.find_last_not_of(" \t\n\r");
    return s.substr(start, end - start + 1);
}

bool parseDate(const string& dateStr, int& day, int& month, int& year) {
    stringstream ss(dateStr);
    char dash1 = '\0', dash2 = '\0';

    if (!(ss >> day >> dash1 >> month >> dash2 >> year)) {
        return false;
    }

    if (dash1 != '-' || dash2 != '-') {
        return false;
    }

    if (month < 1 || month > 12 || year < 1) {
        return false;
    }

    if (month == 2) {
        return day >= 1 && day <= 32;
    }

    if (month == 4 || month == 6 || month == 9 || month == 11) {
        return day >= 1 && day <= 30;
    }

    return day >= 1 && day <= 32;
}

bool isValidDate(const string& dateStr) {
    int inputDay = 0, inputMonth = 0, inputYear = 0;
    if (!parseDate(dateStr, inputDay, inputMonth, inputYear)) {
        return false;
    }

    time_t now = time(nullptr);
    tm* current = localtime(&now);
    int currentYear = current->tm_year + 1900;
    int currentMonth = current->tm_mon + 1;
    int currentDay = current->tm_mday;

    int bsYear = currentYear + 57;
    if (currentMonth < 4) {
        bsYear--;
    }

    int bsMonth = currentMonth + 8;
    if (bsMonth > 12) {
        bsMonth -= 12;
    }

    int bsDay = currentDay + 13;
    if (bsDay > 32) {
        bsDay -= 32;
        bsMonth++;
        if (bsMonth > 12) {
            bsMonth = 1;
            bsYear++;
        }
    }

    int inputValue = inputYear * 10000 + inputMonth * 100 + inputDay;
    int currentValue = bsYear * 10000 + bsMonth * 100 + bsDay;

    return inputValue >= currentValue;
}

string formatBusLine(const Bus& b) {
    return "ID: " + to_string(b.id) + "|Name: " + b.name + "|Number: " + b.number
         + "|Source: " + b.source + "|Destination: " + b.destination
         + "|Date: " + b.date + "|Time: " + b.time
         + "|Price: " + to_string(b.price) + "|Seats: " + to_string(b.seats);
}

void addBus() {
    Bus b;
    ofstream file("bus.txt", ios::app);

    b.id = getRandomBusId();

    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "Enter Bus Name: ";
    getline(cin, b.name);
    cout << "Enter Bus Number: ";
    getline(cin, b.number);

    if (busNumberExists(b.number)) {
        cout << "Bus number already exists. Cannot add duplicate bus number.\n";
        file.close();
        return;
    }

    cout << "Enter Source: ";
    getline(cin, b.source);
    cout << "Enter Destination: ";
    getline(cin, b.destination);

    string dateInput;
    while (true) {
        cout << "Enter Date (DD-MM-YYYY Bikram Sambat): ";
        getline(cin, dateInput);
        if (isValidDate(dateInput)) {
            b.date = dateInput;
            break;
        }
        cout << "Invalid or past date. Please enter a valid Bikram Sambat date in DD-MM-YYYY format.\n";
    }

    cout << "Enter Time: ";
    getline(cin, b.time);

    b.price = readPositiveInt("Enter Price: ");
    b.seats = readPositiveInt("Enter Seat Number: ");

    file << formatBusLine(b) << "\n";
    file.close();

    cout << "Bus Added Successfully! Assigned ID: " << b.id << "\n";
}

void viewBus() {
    ifstream file("bus.txt");
    string line;

    cout << "\n--- Bus List ---\n";
    while (getline(file, line)) {
        cout << line << endl;
    }
    file.close();
}

void updateBus() {
    ifstream file("bus.txt");
    if (!file) {
        cout << "No bus data file found.\n";
        return;
    }

    // Read all lines first so we can both display and process them
    vector<string> lines;
    string line;
    while (getline(file, line)) {
        if (!line.empty()) lines.push_back(line);
    }
    file.close();

    cout << "\n--- Current Buses ---\n";
    for (const auto& l : lines) {
        cout << l << "\n";
    }

    ofstream temp("temp.txt");
    if (!temp) {
        cout << "Unable to create temporary file.\n";
        return;
    }

    int id;
    bool found = false;
    bool updated = false;
    cout << "Enter Bus ID to Update: ";
    cin >> id;

    for (const auto& originalLine : lines) {
        if (originalLine.empty()) {
            continue;
        }

        Bus b;
        if (!parseBusLine(originalLine, b)) {
            temp << originalLine << "\n";
            continue;
        }

        if (b.id == id) {
            found = true;
            cout << "Enter New Details:\n";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');

            cout << "Enter New Name (leave blank to keep current): ";
            string newName;
            getline(cin, newName);
            if (!newName.empty()) {
                b.name = newName;
            }

            cout << "Enter New Number (leave blank to keep current): ";
            string newNumber;
            getline(cin, newNumber);
            if (!newNumber.empty()) {
                if (busNumberExistsExcept(newNumber, b.id)) {
                    cout << "Bus number already exists. Update cancelled.\n";
                    temp << originalLine << "\n";
                    continue;
                }
                b.number = newNumber;
            }

            cout << "Enter New Source (leave blank to keep current): ";
            string newSource;
            getline(cin, newSource);
            if (!newSource.empty()) {
                b.source = newSource;
            }

            cout << "Enter New Destination (leave blank to keep current): ";
            string newDestination;
            getline(cin, newDestination);
            if (!newDestination.empty()) {
                b.destination = newDestination;
            }

            cout << "Enter New Time (leave blank to keep current): ";
            string newTime;
            getline(cin, newTime);
            if (!newTime.empty()) {
                b.time = newTime;
            }

            cout << "Enter New Price (0 to keep current): ";
            int newPrice;
            cin >> newPrice;
            if (newPrice > 0) {
                b.price = newPrice;
            }
            cin.ignore(numeric_limits<streamsize>::max(), '\n');

            cout << "Enter New Seat Number (0 to keep current): ";
            int newSeats;
            cin >> newSeats;
            if (newSeats > 0) {
                b.seats = newSeats;
            }
            cin.ignore(numeric_limits<streamsize>::max(), '\n');

            updated = true;
        }

        temp << formatBusLine(b) << "\n";
    }

    temp.close();

    if (!found) {
        remove("temp.txt");
        cout << "Bus Not Found!\n";
        return;
    }

    remove("bus.txt");
    rename("temp.txt", "bus.txt");

    if (updated) cout << "Bus Updated!\n";
    else cout << "Bus Update Cancelled.\n";
}

void saveDeletedBus(const Bus& b) {
    ofstream file("deleted_buses.txt", ios::app);
    if (!file) {
        cout << "Unable to create deleted bus log file.\n";
        return;
    }

    file << formatBusLine(b) << "\n";
    file.close();
}

void deleteBus() {
    ifstream file("bus.txt");
    if (!file) {
        cout << "No bus data file found.\n";
        return;
    }

    // Read all lines so we can display them first
    vector<string> lines;
    string line;
    while (getline(file, line)) {
        if (!line.empty()) lines.push_back(line);
    }
    file.close();

    cout << "\n--- Current Buses ---\n";
    for (const auto& l : lines) {
        cout << l << "\n";
    }

    ofstream temp("temp.txt");
    if (!temp) {
        cout << "Unable to create temporary file.\n";
        return;
    }

    int id;
    cout << "Enter Bus ID to Delete: ";
    cin >> id;

    bool found = false;
    Bus deletedBus;
    for (const auto& originalLine : lines) {
        if (originalLine.empty()) continue;

        Bus b;
        if (!parseBusLine(originalLine, b)) {
            temp << originalLine << "\n";
            continue;
        }

        if (b.id == id) {
            found = true;
            deletedBus = b;
        } else {
            temp << formatBusLine(b) << "\n";
        }
    }

    temp.close();

    if (!found) {
        remove("temp.txt");
        cout << "Bus Not Found!\n";
        return;
    }

    saveDeletedBus(deletedBus);
    remove("bus.txt");
    rename("temp.txt", "bus.txt");

    cout << "Bus Deleted.\n";
}

// ---------- BOOKING FUNCTIONS ----------
int getRandomTicketNo() {
    static random_device rd;
    static mt19937 gen(rd());
    static uniform_int_distribution<int> dist(1000, 9999);

    int ticketNo;
    do {
        ticketNo = dist(gen);
    } while (ticketNoExists(ticketNo));

    return ticketNo;
}

bool ticketNoExists(int ticketNo) {
    ifstream file("booking.txt");
    if (!file) {
        return false;
    }

    string line;
    while (getline(file, line)) {
        if (line.empty()) {
            continue;
        }

        Booking bk;
        if (parseBookingLine(line, bk) && bk.ticketNo == ticketNo) {
            return true;
        }
    }

    return false;
}

vector<Bus> loadBusesFromFile() {
    vector<Bus> buses;
    ifstream file("bus.txt");
    string line;

    while (getline(file, line)) {
        if (line.empty()) {
            continue;
        }

        Bus b;
        if (parseBusLine(line, b)) {
            buses.push_back(b);
        }
    }

    file.close();
    return buses;
}

vector<Booking> loadBookingsFromFile() {
    vector<Booking> bookings;
    ifstream file("booking.txt");
    string line;

    while (getline(file, line)) {
        if (line.empty()) {
            continue;
        }

        Booking bk;
        if (parseBookingLine(line, bk)) {
            bookings.push_back(bk);
        }
    }

    file.close();
    return bookings;
}

string formatBookingLine(const Booking& bk) {
    return "Ticket No: " + to_string(bk.ticketNo) + "|Passenger Name: " + bk.passengerName
         + "|Contact: " + bk.contact + "|Bus ID: " + to_string(bk.busId)
         + "|Seat No: " + to_string(bk.seatNo) + "|Payment Status: " + bk.paymentStatus
         + "|Bus Number: " + bk.busNumber + "|Date: " + bk.date + "|Time: " + bk.time
         + "|Price: " + to_string(bk.price);
}

bool parseBookingLine(const string& line, Booking& bk) {
    stringstream ss(line);
    string part;
    vector<string> fields;

    while (getline(ss, part, '|')) {
        fields.push_back(part);
    }

    if (fields.empty()) {
        return false;
    }

    bk = {};
    bk.paymentStatus = "Unpaid";
    bk.busNumber = "";
    bk.date = "";
    bk.time = "";
    bk.price = 0;

    if (fields[0].rfind("Ticket No: ", 0) == 0 || fields[0].rfind("TicketNo: ", 0) == 0) {
        for (const string& field : fields) {
            size_t pos = field.find(':');
            if (pos == string::npos) {
                continue;
            }

            string key = trim(field.substr(0, pos));
            string value = trim(field.substr(pos + 1));

            if (key == "Ticket No" || key == "TicketNo") {
                bk.ticketNo = stoi(value);
            }
            else if (key == "Passenger Name" || key == "PassengerName") {
                bk.passengerName = value;
            }
            else if (key == "Contact") {
                bk.contact = value;
            }
            else if (key == "Bus ID" || key == "BusID") {
                bk.busId = stoi(value);
            }
            else if (key == "Seat No" || key == "SeatNo") {
                bk.seatNo = stoi(value);
            }
            else if (key == "Payment Status" || key == "PaymentStatus") {
                bk.paymentStatus = value;
            }
            else if (key == "Bus Number" || key == "BusNumber") {
                bk.busNumber = value;
            }
            else if (key == "Date") {
                bk.date = value;
            }
            else if (key == "Time") {
                bk.time = value;
            }
            else if (key == "Price") {
                bk.price = stoi(value);
            }
        }

        return bk.ticketNo > 0;
    }

    try {
        bk.ticketNo = stoi(fields[0]);
    } catch (...) {
        return false;
    }

    if (fields.size() == 3) {
        bk.passengerName = fields[1];
        bk.contact = "";
        bk.busId = stoi(fields[2]);
        bk.seatNo = 0;
        return true;
    }

    if (fields.size() >= 5) {
        bk.passengerName = fields[1];
        bk.contact = fields[2];
        bk.busId = stoi(fields[3]);
        bk.seatNo = stoi(fields[4]);
        if (fields.size() >= 6) {
            bk.paymentStatus = fields[5];
        }
        if (fields.size() >= 10) {
            bk.busNumber = fields[6];
            bk.date = fields[7];
            bk.time = fields[8];
            bk.price = stoi(fields[9]);
        }
        return true;
    }

    return false;
}

bool isSeatBooked(int seatNo, const Bus& bus, const vector<Booking>& bookings) {
    for (size_t i = 0; i < bookings.size(); ++i) {
        if (bookings[i].busId == bus.id && bookings[i].seatNo == seatNo) {
            return true;
        }
    }
    return false;
}

void displaySeatLayout(const Bus& bus, const vector<Booking>& bookings) {
    cout << "\n--- Seat Layout for " << bus.name << " (" << bus.number << ") ---\n";
    cout << "Legend: [O] Available | [X] Booked\n";

    int seatsPerRow = 4;
    for (int seatNo = 1; seatNo <= bus.seats; ++seatNo) {
        cout << (isSeatBooked(seatNo, bus, bookings) ? "[X" : "[O") << seatNo << "] ";
        if (seatNo % seatsPerRow == 0 || seatNo == bus.seats) {
            cout << "\n";
        }
    }
    cout << "\n";
}

void bookTicket() {
    vector<Bus> buses = loadBusesFromFile();
    vector<Booking> bookings = loadBookingsFromFile();

    if (buses.empty()) {
        cout << "No buses have been added yet.\n";
        return;
    }

    vector<Bus> availableBuses;
    for (size_t i = 0; i < buses.size(); ++i) {
        Bus bus = buses[i];
        int bookedSeats = 0;
        for (size_t j = 0; j < bookings.size(); ++j) {
            if (bookings[j].busId == bus.id) {
                ++bookedSeats;
            }
        }

        if (bus.seats - bookedSeats > 0) {
            availableBuses.push_back(bus);
        }
    }

    if (availableBuses.empty()) {
        cout << "No buses with remaining seats are available right now.\n";
        return;
    }

    cout << "\n--- Available Buses ---\n";
    for (size_t i = 0; i < availableBuses.size(); ++i) {
        Bus bus = availableBuses[i];
        int bookedSeats = 0;
        for (size_t j = 0; j < bookings.size(); ++j) {
            if (bookings[j].busId == bus.id) {
                ++bookedSeats;
            }
        }

        cout << "ID: " << bus.id << " | Bus: " << bus.name << " (" << bus.number << ")\n";
        cout << "   Route: " << bus.source << " -> " << bus.destination
             << " | Date: " << bus.date << " | Time: " << bus.time
             << " | Price: " << bus.price << "\n";
        cout << "   Seats Available: " << (bus.seats - bookedSeats) << " / " << bus.seats << "\n";
    }

    int selectedBusId;
    cout << "Enter Bus ID to book: ";
    cin >> selectedBusId;

    Bus selectedBus;
    bool busFound = false;
    for (size_t i = 0; i < availableBuses.size(); ++i) {
        if (availableBuses[i].id == selectedBusId) {
            selectedBus = availableBuses[i];
            busFound = true;
            break;
        }
    }

    if (!busFound) {
        cout << "Bus ID not found or no seats are available.\n";
        return;
    }

    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    Booking bk;
    bk.ticketNo = getRandomTicketNo();

    displaySeatLayout(selectedBus, bookings);

    int chosenSeat = 0;
    while (true) {
        cout << "Enter Seat Number to Book: ";
        cin >> chosenSeat;

        if (cin.fail() || chosenSeat < 1 || chosenSeat > selectedBus.seats) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Please enter a valid seat number between 1 and " << selectedBus.seats << ".\n";
            continue;
        }

        if (isSeatBooked(chosenSeat, selectedBus, bookings)) {
            cout << "Seat " << chosenSeat << " is already booked. Please choose another seat.\n";
            continue;
        }

        break;
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    cout << "Enter Passenger Name: ";
    getline(cin, bk.passengerName);

    cout << "Enter Contact Number: ";
    getline(cin, bk.contact);

    while (true) {
        cout << "Payment Status (paid/unpaid): ";
        getline(cin, bk.paymentStatus);
        transform(bk.paymentStatus.begin(), bk.paymentStatus.end(), bk.paymentStatus.begin(), ::tolower);
        if (bk.paymentStatus == "paid" || bk.paymentStatus == "unpaid") {
            break;
        }
        cout << "Please enter either 'paid' or 'unpaid'.\n";
    }

    bk.busId = selectedBus.id;
    bk.seatNo = chosenSeat;
    bk.busNumber = selectedBus.number;
    bk.date = selectedBus.date;
    bk.time = selectedBus.time;
    bk.price = selectedBus.price;

    ofstream file("booking.txt", ios::app);
    file << formatBookingLine(bk) << "\n";
    file.close();

    cout << "Ticket Booked Successfully!\n";
    cout << "Assigned Ticket No: " << bk.ticketNo << "\n";
    cout << "Assigned Seat No: " << bk.seatNo << "\n";
}

void displayBooking(const Booking& bk, const vector<Bus>& buses) {
    string busName = "Unknown";

    for (size_t j = 0; j < buses.size(); ++j) {
        if (buses[j].id == bk.busId) {
            busName = buses[j].name;
            break;
        }
    }

    cout << left << setw(12) << bk.ticketNo
         << setw(20) << bk.passengerName
         << setw(15) << bk.contact
         << setw(18) << busName
         << setw(12) << bk.busNumber
         << setw(12) << bk.date
         << setw(10) << bk.time
         << setw(10) << bk.price
         << setw(10) << bk.seatNo
         << setw(10) << bk.paymentStatus << "\n";
}

void viewBookings() {
    vector<Booking> bookings = loadBookingsFromFile();
    vector<Bus> buses = loadBusesFromFile();

    if (bookings.empty()) {
        cout << "No bookings yet.\n";
        return;
    }

    int choice;
    cout << "\n===== VIEW BOOKINGS =====\n";
    cout << "1. View All Bookings\n2. View Booking by Ticket No\n";
    cout << "Enter choice: ";

    while (true) {
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid choice!\n";
            cout << "Enter choice: ";
            continue;
        }

        if (choice == 1) {
            cout << "\n--- All Bookings ---\n";
            cout << left << setw(12) << "Ticket"
                 << setw(20) << "Passenger"
                 << setw(15) << "Contact"
                 << setw(18) << "Bus"
                 << setw(12) << "Bus No"
                 << setw(12) << "Date"
                 << setw(10) << "Time"
                 << setw(10) << "Price"
                 << setw(10) << "Seat"
                 << setw(10) << "Payment" << "\n";
            cout << string(129, '-') << "\n";
            for (size_t i = 0; i < bookings.size(); ++i) {
                displayBooking(bookings[i], buses);
            }
            break;
        }
        else if (choice == 2) {
            int ticketNo;
            bool found = false;
            cout << "Enter Ticket No: ";
            cin >> ticketNo;

            for (size_t i = 0; i < bookings.size(); ++i) {
                if (bookings[i].ticketNo == ticketNo) {
                    displayBooking(bookings[i], buses);
                    found = true;
                    break;
                }
            }

            if (!found) {
                cout << "Booking Not Found!\n";
            }
            break;
        }
        else {
            cout << "Invalid choice!\n";
            cout << "Enter choice: ";
        }
    }
}

void updateBooking() {
    vector<Booking> bookings = loadBookingsFromFile();
    vector<Bus> buses = loadBusesFromFile();
    int ticketNo;
    bool found = false;

    if (bookings.empty()) {
        cout << "No bookings to update.\n";
        return;
    }

    cout << "\n--- All Bookings ---\n";
    cout << left << setw(12) << "Ticket"
         << setw(20) << "Passenger"
         << setw(15) << "Contact"
         << setw(18) << "Bus"
         << setw(12) << "Bus No"
         << setw(12) << "Date"
         << setw(10) << "Time"
         << setw(10) << "Price"
         << setw(10) << "Seat"
         << setw(10) << "Payment" << "\n";
    cout << string(129, '-') << "\n";
    for (size_t i = 0; i < bookings.size(); ++i) {
        displayBooking(bookings[i], buses);
    }

    cout << "Enter Ticket No to Update: ";
    cin >> ticketNo;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    for (size_t i = 0; i < bookings.size(); ++i) {
        if (bookings[i].ticketNo == ticketNo) {
            found = true;

            cout << "Enter New Passenger Name (leave blank to keep current): ";
            string newName;
            getline(cin, newName);
            if (!newName.empty()) {
                bookings[i].passengerName = newName;
            }

            cout << "Enter New Contact Number (leave blank to keep current): ";
            string newContact;
            getline(cin, newContact);
            if (!newContact.empty()) {
                bookings[i].contact = newContact;
            }

            while (true) {
                cout << "Enter Payment Status (paid/unpaid, leave blank to keep current): ";
                string newPayment;
                getline(cin, newPayment);

                if (newPayment.empty()) {
                    break;
                }

                transform(newPayment.begin(), newPayment.end(), newPayment.begin(), ::tolower);
                if (newPayment == "paid" || newPayment == "unpaid") {
                    bookings[i].paymentStatus = newPayment;
                    break;
                }

                cout << "Please enter either 'paid' or 'unpaid'.\n";
            }

            // Allow updating seat number with validation
            // Find the bus for this booking
            Bus* busPtr = nullptr;
            for (size_t bidx = 0; bidx < buses.size(); ++bidx) {
                if (buses[bidx].id == bookings[i].busId) {
                    busPtr = &buses[bidx];
                    break;
                }
            }

            if (busPtr == nullptr) {
                cout << "Associated bus not found. Cannot change seat number.\n";
            } else {
                // Show current seat layout like booking flow
                displaySeatLayout(*busPtr, bookings);

                while (true) {
                    cout << "Enter New Seat Number (0 to keep current): ";
                    int newSeat;
                    if (!(cin >> newSeat)) {
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        cout << "Please enter a valid number.\n";
                        continue;
                    }

                    if (newSeat == 0) {
                        // keep current
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        break;
                    }

                    if (newSeat < 1 || newSeat > busPtr->seats) {
                        cout << "Please enter a seat between 1 and " << busPtr->seats << ".\n";
                        continue;
                    }

                    bool occupied = false;
                    for (size_t k = 0; k < bookings.size(); ++k) {
                        if (k == i) continue; // ignore current booking
                        if (bookings[k].busId == bookings[i].busId && bookings[k].seatNo == newSeat) {
                            occupied = true;
                            break;
                        }
                    }

                    if (occupied) {
                        cout << "Seat " << newSeat << " is already booked. Please choose another seat.\n";
                        continue;
                    }

                    bookings[i].seatNo = newSeat;
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    break;
                }
            }

            break;
        }
    }

    if (!found) {
        cout << "Booking Not Found!\n";
        return;
    }

    ofstream file("booking.txt", ios::trunc);
    for (size_t i = 0; i < bookings.size(); ++i) {
        file << formatBookingLine(bookings[i]) << "\n";
    }
    file.close();

    cout << "Booking Updated!\n";
}

void saveCancelledBooking(const Booking& bk) {
    ofstream file("cancelled_bookings.txt", ios::app);
    if (!file) {
        cout << "Unable to create cancelled booking log file.\n";
        return;
    }

    file << formatBookingLine(bk) << "\n";
    file.close();
}

void cancelBooking() {
    vector<Booking> bookings = loadBookingsFromFile();
    vector<Bus> buses = loadBusesFromFile();

    if (bookings.empty()) {
        cout << "No bookings to cancel.\n";
        return;
    }

    cout << "\n--- All Bookings ---\n";
    cout << left << setw(12) << "Ticket"
         << setw(20) << "Passenger"
         << setw(15) << "Contact"
         << setw(18) << "Bus"
         << setw(12) << "Bus No"
         << setw(12) << "Date"
         << setw(10) << "Time"
         << setw(10) << "Price"
         << setw(10) << "Seat"
         << setw(10) << "Payment" << "\n";
    cout << string(129, '-') << "\n";
    for (size_t i = 0; i < bookings.size(); ++i) {
        displayBooking(bookings[i], buses);
    }

    int ticketNo;
    cout << "Enter Ticket No to Cancel: ";
    cin >> ticketNo;

    bool found = false;
    vector<Booking> remainingBookings;
    for (size_t i = 0; i < bookings.size(); ++i) {
        if (bookings[i].ticketNo == ticketNo) {
            found = true;
            saveCancelledBooking(bookings[i]);
        } else {
            remainingBookings.push_back(bookings[i]);
        }
    }

    ofstream file("booking.txt", ios::trunc);
    for (size_t i = 0; i < remainingBookings.size(); ++i) {
        file << formatBookingLine(remainingBookings[i]) << "\n";
    }
    file.close();

    if (found) {
        cout << "Booking Cancelled and saved to cancelled_bookings.txt.\n";
    } else {
        cout << "Booking Not Found.\n";
    }
}